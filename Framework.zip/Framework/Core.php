<?php

/*
 * @author Matheus Garcia <matheus.mfgarcia@gmail.com>
 */

namespace Framework;

class Core
{
    static $controller;
    static $action;

}